var arcadiaRoot = null, infoLabel = null, resLine1 = null, resLine2 = null, resLine3 = null;

var serpuloItems = [
    { name: "copper", tag: "[#d99d73]cu:[]" }, { name: "lead", tag: "[#8c7fa9]pb:[]" },
    { name: "metaglass", tag: "[#ebeef5]ms:[]" }, { name: "graphite", tag: "[#6b77a1]c:[]" },
    { name: "sand", tag: "[#f7cba4]p:[]" }, { name: "coal", tag: "[#6e6e6e]c:[]" },
    { name: "titanium", tag: "[#8da1e3]ti:[]" }, { name: "thorium", tag: "[#f9a3c7]t:[]" },
    { name: "silicon", tag: "[#8e929c]si:[]" }, { name: "plastanium", tag: "[#cbd97f]pl:[]" },
    { name: "phase-fabric", tag: "[#f4ba6e]fz:[]" }, { name: "surge-alloy", tag: "[#f3e979]ki:[]" }
];

var erekirOnlyItems = [
    { name: "beryllium", tag: "[#3a8f64]be:[]" }, { name: "tungsten", tag: "[#768a9a]w:[]" },
    { name: "oxide", tag: "[#e4ffd6]ox:[]" }, { name: "carbide", tag: "[#89769a]cb:[]" },
    { name: "graphite", tag: "[#6b77a1]c:[]" }, { name: "sand", tag: "[#f7cba4]p:[]" },
    { name: "silicon", tag: "[#8e929c]si:[]" }, { name: "thorium", tag: "[#f9a3c7]t:[]" },
    { name: "phase-fabric", tag: "[#f4ba6e]fz:[]" }, { name: "surge-alloy", tag: "[#f3e979]ki:[]" }
];

var erekirExtraItems = [
    { name: "beryllium", tag: "[#3a8f64]be:[]" }, { name: "tungsten", tag: "[#768a9a]w:[]" },
    { name: "oxide", tag: "[#e4ffd6]ox:[]" }, { name: "carbide", tag: "[#89769a]cb:[]" }
];

var serpuloExtraItems = [
    { name: "copper", tag: "[#d99d73]cu:[]" }, { name: "lead", tag: "[#8c7fa9]pb:[]" },
    { name: "metaglass", tag: "[#ebeef5]ms:[]" }, { name: "coal", tag: "[#6e6e6e]c:[]" },
    { name: "titanium", tag: "[#8da1e3]ti:[]" }, { name: "plastanium", tag: "[#cbd97f]pl:[]" }
];

function isErekirMap(core) {
    try {
        if (Vars.state.rules != null && Vars.state.rules.planet != null && String(Vars.state.rules.planet.name) === "erekir") return true;
        if (core != null && core.block != null) {
            var bn = String(core.block.name);
            if (bn === "core-bastion" || bn === "core-citadel" || bn === "core-acropolis") return true;
        }
    } catch (e) {}
    return false;
}

function isFuelGenerator(block) {
    if (block == null || !block.outputsPower) return false;
    var bn = String(block.name);
    if (bn === "solar-panel" || bn === "large-solar-panel" || bn === "thermal-generator" || bn === "turbine-condenser") return false;
    return block.hasItems || block.hasLiquids;
}

function buildArcadiaHUD() {
    if (arcadiaRoot != null || Vars.ui == null || Vars.ui.hudGroup == null) return;
    arcadiaRoot = new Table();
    arcadiaRoot.setFillParent(true);
    arcadiaRoot.top();
    arcadiaRoot.touchable = Touchable.disabled;

    var box = new Table(Styles.black6);
    box.margin(6);
    box.left();
    infoLabel = box.add("[cyan]ARCADIA[] | ���: 0% | ����: 0").left().get();
    box.row();
    resLine1 = box.add("����: ---").left().padTop(2).get();
    box.row();
    resLine2 = box.add("").left().get();
    box.row();
    resLine3 = box.add("").left().get();

    arcadiaRoot.add(box).top().expandY().padTop(6);
    Vars.ui.hudGroup.addChild(arcadiaRoot);
}

function updatePowerAndSafety() {
    if (!Vars.state.isGame()) return;
    var player = Vars.player;
    if (player == null || player.team() == null) return;
    var team = player.team(), core = team.core();

    if (core != null && resLine1 != null) {
        var items = core.items, p1 = [], p2 = [], p3 = [];
        if (isErekirMap(core)) {
            for (var e = 0; e < erekirOnlyItems.length; e++) {
                var ec = erekirOnlyItems[e], ei = Vars.content.item(ec.name);
                if (ei != null) (e < 5 ? p1 : p2).push(ec.tag + UI.formatAmount(items.get(ei)));
            }
            var hasS = false;
            for (var s = 0; s < serpuloExtraItems.length; s++) {
                var sc = serpuloExtraItems[s], si = Vars.content.item(sc.name);
                if (si != null) {
                    var sa = items.get(si);
                    if (sa > 0) hasS = true;
                    p3.push(sc.tag + UI.formatAmount(sa));
                }
            }
            resLine1.setText(p1.join(" "));
            resLine2.setText(p2.join(" "));
            resLine3.setText(hasS ? p3.join(" ") : "");
        } else {
            for (var i = 0; i < serpuloItems.length; i++) {
                var c = serpuloItems[i], it = Vars.content.item(c.name);
                if (it != null) (i < 6 ? p1 : p2).push(c.tag + UI.formatAmount(items.get(it)));
            }
            var hasE = false;
            for (var j = 0; j < erekirExtraItems.length; j++) {
                var xc = erekirExtraItems[j], xi = Vars.content.item(xc.name);
                if (xi != null) {
                    var xa = items.get(xi);
                    if (xa > 0) hasE = true;
                    p3.push(xc.tag + UI.formatAmount(xa));
                }
            }
            resLine1.setText(p1.join(" "));
            resLine2.setText(p2.join(" "));
            resLine3.setText(hasE ? p3.join(" ") : "");
        }
    }

    var mainGraph = null, totalStored = 0, totalCapacity = 0, graphs = new ObjectSet();
    Groups.build.each(function(b) {
        if (b.team == team && b.power != null && b.power.graph != null) {
            var g = b.power.graph;
            if (!graphs.contains(g)) {
                graphs.add(g);
                totalStored += g.getBatteryStored();
                totalCapacity += g.getTotalBatteryCapacity();
                if (mainGraph == null || g.getTotalBatteryCapacity() > mainGraph.getTotalBatteryCapacity()) mainGraph = g;
            }
        }
    });

    var batPercent = totalCapacity > 0 ? (totalStored / totalCapacity) * 100 : 0;

    if (!Vars.state.isPaused()) {
        Groups.build.each(function(b) {
            if (b.team != team) return;
            if (b.block == Blocks.thoriumReactor) {
                var cryo = b.liquids != null ? b.liquids.get(Liquids.cryofluid) : 0, heat = b.heat != null ? b.heat : 0;
                if (cryo < 3.5 || heat > 0.15) { if (b.enabled) b.enabled = false; return; }
            }
            if (isFuelGenerator(b.block) && totalCapacity > 0) {
                if (batPercent >= 99.9) {
                    if (b.enabled) b.enabled = false;
                } else if (batPercent <= 50.0) {
                    if (b.block == Blocks.thoriumReactor) {
                        var c2 = b.liquids != null ? b.liquids.get(Liquids.cryofluid) : 0, h2 = b.heat != null ? b.heat : 0;
                        if (c2 >= 8.0 && h2 < 0.05 && !b.enabled) b.enabled = true;
                    } else if (!b.enabled) b.enabled = true;
                }
            }
        });
    }

    if (infoLabel != null) {
        var batColor = batPercent >= 99.9 ? "[cyan]" : (batPercent <= 50.0 ? "[red]" : "[yellow]");
        var bal = mainGraph != null ? Math.round(mainGraph.getPowerBalance() * 60) : 0;
        var balStr = (bal >= 0 ? "[green]+" : "[red]") + bal + "/s[]";
        infoLabel.setText("[cyan]ARCADIA[]  ���: " + batColor + batPercent.toFixed(0) + "%[]  ����: " + balStr);
    }
}

Events.on(ClientLoadEvent, function() { try { buildArcadiaHUD(); } catch (e) {} });

var tickCounter = 0;
Events.run(Trigger.update, function() {
    try {
        if (arcadiaRoot == null && Vars.ui != null && Vars.ui.hudGroup != null) buildArcadiaHUD();
        if (arcadiaRoot != null && Vars.ui != null && Vars.ui.hudfrag != null) arcadiaRoot.visible = Vars.state.isGame() && Vars.ui.hudfrag.shown;
        if (++tickCounter >= 15) { tickCounter = 0; updatePowerAndSafety(); }
    } catch (e) {}
});
